<?php

require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB;
$systemcontext = get_context_instance(CONTEXT_SYSTEM);
$PAGE->set_context($systemcontext);
$PAGE->set_url('/local/upload/help.php');
$PAGE->set_pagelayout('admin');
$strheading = get_string('pluginname', 'local_upload') . ' : ' . get_string('manual', 'local_upload');
$PAGE->set_title($strheading);
if(!(has_capability('local/upload:manage', $systemcontext))){
	echo print_error('no permission');
}

require_login();

$PAGE->set_heading($SITE->fullname);
$PAGE->navbar->add(get_string('sendrandomemail', 'local_upload'), new moodle_url('/local/upload/index.php'));
$PAGE->navbar->add(get_string('manual', 'local_upload'));
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('manual', 'local_upload'));


echo get_string('help_1', 'local_upload');

?>
