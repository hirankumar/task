<?php
defined('MOODLE_INTERNAL') || die();



 $ADMIN->add('accounts', new admin_externalpage('sendrandomemailtousers', new lang_string('sendrandomemailtousers','local_upload'), "$CFG->wwwroot/local/upload/index.php"));


