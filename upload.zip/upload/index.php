<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Bulk user email script from a comma separated file
 *
 * @package    local
 * @subpackage upload
 * @copyright  2024 
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/csvlib.class.php');


$iid = optional_param('iid', '', PARAM_INT);

require_login();

$systemcontext = context_system::instance();
$PAGE->set_context($systemcontext);

$PAGE->set_pagelayout('admin');
global $USER, $DB , $OUTPUT;

$returnurl = new moodle_url('/local/upload/index.php');
if (!has_capability('local/upload:manage',$systemcontext) ) {  
	print_error('You dont have permission');
}
$PAGE->set_url('/local/upload/index.php');
$PAGE->set_heading(get_string('sendrandomemail', 'local_upload'));
$strheading = get_string('sendrandomemail', 'local_upload');
$PAGE->set_title($strheading);
$PAGE->navbar->add(get_string('sendrandomemail', 'local_upload'));
$STD_FIELDS = array('firstname','lastname','email');
$PRF_FIELDS = array();
$mform = new local_upload\forms\uploadform();
if ($mform->is_cancelled()) {

	redirect($returnurl);
}
if ($formdata = $mform->get_data()) {

    echo $OUTPUT->header();
	$iid = csv_import_reader::get_new_iid('userfile');
	$cir = new csv_import_reader($iid, 'userfile');
	$content = $mform->get_file_content('userfile');
	$readcount = $cir->load_csv_content($content, $formdata->encoding, $formdata->delimiter_name);     
	$cir->init();
	$linenum = 1;	
	$uploadlibfunctions = new local_upload\upload\uploadlibfunctions();
	$filecolumns = $uploadlibfunctions->uu_validate_user_upload_columns($cir, $STD_FIELDS, $PRF_FIELDS, $returnurl);
	$upload= new local_upload\upload\uploadfunctionality();
	$upload->upload_users_email($cir,$filecolumns, $formdata);
	echo $OUTPUT->footer();
}
else{
	echo $OUTPUT->header();	
	echo $OUTPUT->heading(get_string('sendrandomemail', 'local_upload'));
	echo html_writer::link(new moodle_url('/local/upload/sample.php?format=csv'),'Sample',array('class'=>'btn btn-info','id'=>'download_users'));	
	echo html_writer::link(new moodle_url('/local/upload/help.php'),'Help manual' ,array('class'=>'btn btn-info','id'=>'download_courses','target'=>'__blank'));
	echo html_writer::link(new moodle_url('/local/upload/view.php'),'View Sent User' ,array('class'=>'btn btn-info','id'=>'download_courses','target'=>'__blank'));	
	$mform->display();	
	echo $OUTPUT->footer();
	die;
}