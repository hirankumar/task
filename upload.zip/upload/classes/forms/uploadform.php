<?php
namespace local_upload\forms;
defined('MOODLE_INTERNAL') || die();

require_once $CFG->libdir . '/formslib.php';

use moodleform;
use csv_import_reader;
use core_text;


class uploadform extends moodleform{


	function definition() {
		$mform = $this->_form;

		$mform->addElement('header', 'settingsheader', get_string('upload'));

		$mform->addElement('filepicker', 'userfile', get_string('file'));
		$mform->addRule('userfile', null, 'required');

		
		$mform->addElement('hidden',  'delimiter_name');
		$mform->setType('delimiter_name', PARAM_TEXT);
		$mform->setDefault('delimiter_name',  'comma');


		$mform->addElement('hidden',  'encoding');
		$mform->setType('encoding', PARAM_RAW);
		$mform->setDefault('encoding',  'UTF-8');

		$this->add_action_buttons(true, get_string('upload'));
	}

}