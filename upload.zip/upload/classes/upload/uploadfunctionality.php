<?php
namespace local_upload\upload;
use core_text;
use core_user;
use html_writer;


class uploadfunctionality{
    

    private $data;
    
    private $errors = array();
    
    private $mfields = array();    
        
    private $failcount=0;
    
    private $sentcount=0;

    private $errorcount=0;

    private $line_number;

    private $firstname;

    private $lastname;

    private $email;

    
    
    function __construct($data=null){    
        $this->data = $data;
    }
    
    public function upload_users_email($cir,$filecolumns, $formdata){
           
        global $DB,$USER, $CFG;
    
        $inserted = 0; 
        $updated = 0; 
        $linenum = 1;  

        while($line=$cir->next()){

            $linenum++;
            $user = new \stdClass();

            foreach ($line as $keynum => $value) {
                if (!isset($filecolumns[$keynum])) {
                    continue;
                }
                $key = $filecolumns[$keynum];
                $user->$key = trim($value);
            }
            $this->data[]=$user;  
            $this->line_number = $linenum;
            $this->errors = array();
            $this->mfields = array();

            $userdata = new \stdclass();
            $userdata->firstname = $user->firstname;    
            $userdata->lastname = $user->lastname;
            $userdata->email = $user->email;
            $eachuser = $DB->get_record('user',array('email' => $user->email,'deleted' => 0, 'suspended' => 0));

            if(!$user->email){
                echo "<div class='alert alert-danger'>
                    <strong>Warning!</strong> Please provide email at line $this->line_number.</div>";
                    $this->errors[] = "Please provide email at line $this->line_number.";
                    $this->mfields[] = "email";
                    $this->failcount++;
                    continue;
            }

            if(!$user->firstname){
                echo "<div class='alert alert-danger'>
                    <strong>Warning!</strong> Please provide firstname at line $this->line_number.</div>";
                    $this->errors[] = "Please provide firstname at line $this->line_number.";
                    $this->mfields[] = "firstname";
                    $this->failcount++;
                    continue;
                   
            }

            if(!$user->lastname){
                echo "<div class='alert alert-danger'>
                    <strong>Warning!</strong> Please provide lastname at line $this->line_number.</div>";
                    $this->errors[] = "Please provide lastname at line $this->line_number.";
                    $this->mfields[] = "lastname";
                    $this->failcount++;
                    continue;
            }

            if($eachuser){
                
                $fullname = $user->firstname.' '.$user->lastname;
                $body = '<p>Dear '.$fullname.',</p><p>Your account has been created succefully, Please click here login</p>';
                $mailbody = format_text($body, FORMAT_HTML);
                $subject = get_string('accountcreation','local_upload');
                $touser =  new \stdClass();
                $touser->id = $eachuser->id;
                $touser->email =  $user->email; 
                $fromuser =  $DB->get_record('user',array('id' => 2));
                $sent = email_to_user($touser, $fromuser, $subject, $mailbody, $body);


                $todata = new \stdClass();
                $todata->userid = $eachuser->id;
                $todata->firstname = $user->firstname; 
                $todata->lastname = $user->lastname; 
                $todata->email =$user->email; 
                $todata->status = $sent > 0 ? 1 : 0; 
                $todata->usermodified = $USER->id;
                $todata->timemodified = time();
                
                $DB->insert_record('local_randomemails', $todata);
                $this->sentcount++;
            }else{
                 echo "<div class='alert alert-danger'>
                    <strong>Warning!</strong> Student with email $user->email not existed into lms at line $this->line_number.</div>";
                    $this->errors[] = "Student with email $user->email not existed into lms at line $this->line_number.";
                    $this->mfields[] = "email";
                    $this->failcount++;
                    continue;
            }

            $data[]=$user;		
	    }        

        if($this->data){
            $upload_info =  '<div class="critera_error1"><h3 style="text-decoration: underline;">Send Random Emails</h3>
            <div class=local_courses_master_success>Total '.$this->sentcount . ' new random emails sent to the user.</div>
            <div class=local_courses_master_error>Total '.$this->failcount . ' errors occured in the random emails.</div></div>';
            $button=html_writer::tag('button',get_string('button','local_upload'),array('class'=>'btn btn-primary'));
            $link= html_writer::tag('a',$button,array('href'=>$CFG->wwwroot. '/local/upload/index.php'));
            $upload_info .='<div class="w-full pull-left text-xs-center">'.$link.'</div>';

            mtrace( $upload_info);
        } else {
            echo'<div class="critera_error">File with users data is not available.</div>';
        }
    } 
}  

