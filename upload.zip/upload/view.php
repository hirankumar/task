<?php

require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB;
$systemcontext = get_context_instance(CONTEXT_SYSTEM);
$PAGE->set_context($systemcontext);
$PAGE->set_url('/local/upload/help.php');
$PAGE->set_pagelayout('admin');
$strheading = get_string('pluginname', 'local_upload') . ' : ' . get_string('manual', 'local_upload');
$PAGE->set_title($strheading);
if(!(has_capability('local/upload:manage', $systemcontext))){
	echo print_error('no permission');
}

require_login();

$PAGE->set_heading($SITE->fullname);
$PAGE->navbar->add(get_string('sendrandomemail', 'local_upload'), new moodle_url('/local/upload/index.php'));
$PAGE->navbar->add(get_string('view', 'local_upload'));
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('view', 'local_upload'));

$userdate = $DB->get_records('local_randomemails',array('status' => 1));
$data=[];

foreach ($userdate as $user) {

	$rec = new stdclass();

	$rec->userfirstname = $user->firstname;
	$rec->lastname      = $user->lastname;
	$rec->email         = $user->email;
	$rec->sentdate      = userdate($user->timemodified,'%d/%m/%Y');

	$data [] = $rec;
}


	echo $OUTPUT->render_from_template('local_upload/userview',array('users' => $data));



?>
